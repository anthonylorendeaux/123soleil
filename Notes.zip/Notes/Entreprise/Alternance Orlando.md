# Quick links
* [[Notes S1000D]]
* [[Elasticsearch]]
* [[Java]]
* [[Angular]]

## Résumé du travail effectué

- Septembre
    - Installation de l’environnement du projet (Backend et frontend).
    - Explication du sujet de l’alternance (S1000D Common library).
    - Recherche sur la S100D et review des spécifications technique autour de la S100D.
    - Ticket sur les temporary merge request : https://orlandotechpubs.atlassian.net/browse/FTD-22356
- Octobre
    - Période de cours
- Novembre
    - Ticket sur les révisions de graph : https://orlandotechpubs.atlassian.net/browse/FTD-22356
    - Ticket sur les liens dans les <zone> : https://orlandotechpubs.atlassian.net/browse/FTD-21738
    - Ticket sur le nombre de caractère maximum sur les noms de fleet : https://orlandotechpubs.atlassian.net/browse/FTD-22424
    - Ticket sur les - dans les noms de pdf : https://orlandotechpubs.atlassian.net/browse/FTD-22755
    - Travail sur les spécifications sur le sujet de stage
        - Élaboration des spécifications par itération (une réunion par semaine)
        - Maquette: https://www.figma.com/file/tTQOHXvtO7R9sBgq4SHEql/CIL---Mockup?node-id=0%3A1&t=Mx746wTrBvd55FGG-0
- Décembre
    - Analyses
- Janvier
    - Analyse Common Content library:
        - https://orlandotechpubs.atlassian.net/browse/FTD-23240?atlOrigin=eyJpIjoiMTZmNTRmNTcxNjhkNDI4N2IzYTJjZWI1NDY0ODYwMzEiLCJwIjoiaiJ9
        - https://orlandotechpubs.atlassian.net/browse/FTD-23241?atlOrigin=eyJpIjoiYjE2YWFhYTMzOTJjNGRkOGIyMmJmMTI4NzMxNTUzZjgiLCJwIjoiaiJ9
        - https://orlandotechpubs.atlassian.net/browse/FTD-23239?atlOrigin=eyJpIjoiNzIzNGExYWE0MzRjNGMwOWEwMTYyOTgxMTE1MjA3M2EiLCJwIjoiaiJ9
        - https://orlandotechpubs.atlassian.net/browse/FTD-23248?atlOrigin=eyJpIjoiNTQwOGZlOWQzMzU2NDkwOWIxMTJhMGE0NDcxZjkwZjEiLCJwIjoiaiJ9
        - https://orlandotechpubs.atlassian.net/browse/FTD-23250?atlOrigin=eyJpIjoiZGMxZDYxMmE5ZDY3NDk1MzljYTM3Y2Y4NDY4ZDc1YjIiLCJwIjoiaiJ9
        - https://orlandotechpubs.atlassian.net/browse/FTD-23254?atlOrigin=eyJpIjoiMTAxZWY5OTM0NzI2NDY0NDk4MDU1Yjg5OGUyOGY1ZDAiLCJwIjoiaiJ9
        - https://orlandotechpubs.atlassian.net/browse/FTD-23242?atlOrigin=eyJpIjoiZjk4NjBkOTM0MTIxNDE1MzhjZDM3MmQ3Njc1YmI2MDMiLCJwIjoiaiJ9
- Février
    - Formation angular (openclassroom):
        - [Formation 1](https://openclassrooms.com/fr/courses/7471261-debutez-avec-angular)
        - [Formation 2](https://openclassrooms.com/fr/courses/7471271-completez-vos-connaissances-sur-angular)
        - [Formation 3](https://openclassrooms.com/fr/courses/7471281-perfectionnez-vous-sur-angular)
    - Ticket sur l’api : https://orlandotechpubs.atlassian.net/browse/FTD-23260
    - Ticket sur la main-view : https://orlandotechpubs.atlassian.net/browse/FTD-23240
    - Ticket sur la génération de clés : https://orlandotechpubs.atlassian.net/browse/FTD-23248
    - Ticket sur la création d’xsd : https://orlandotechpubs.atlassian.net/browse/FTD-23239
    - Ticket sur la création de common content : https://orlandotechpubs.atlassian.net/browse/FTD-23250
    
    Difficultés rencontré :
    
    - Eclispe qui compilé mal les jar.
    - Angular 14 dans AngularJS.
    - Transformation à refaire et ticket de 2j en 5j : https://orlandotechpubs.atlassian.net/browse/FTD-23250.
- Mars
    - Utilisation d’elasticsearch pour filtrer les tickets : https://orlandotechpubs.atlassian.net/browse/FTD-23242?atlOrigin=eyJpIjoiMDhiYmVjZDQyOGIwNDVmNmI0YzBkMzEzY2M0N2M4ODMiLCJwIjoiaiJ9

> Voir les jiras 
